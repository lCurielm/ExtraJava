package maze;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class MazeGame {
    public static final int HEIGHT = 19;
    public static final int  WIDTH = 39;
    private static final int COL = 1;
    private static final int ROW = 0;
    private Scanner playerInput;
    private boolean[][] blocked;
    private boolean[][] visited;
    private int[] player;
    private int[] goal;
    private int[] start;

    public MazeGame(String mazeFile) throws FileNotFoundException
    {
        this(mazeFile, new Scanner(System.in));
    }

    public MazeGame(String mazeFile, Scanner playerInput) throws FileNotFoundException
    {
        this.playerInput = playerInput;
        loadMaze(mazeFile);
    }

    public void playGame(){
        String move = "";
        do {
            prompt();
            move += playerInput.nextLine();
        } while (!makeMove(move));
        if (playerAtGoal()) {
            System.out.println("You won!");
        }else {
            System.out.println("Goodbye!");
        }
    }

    public void printMaze(){
        System.out.println("*---------------------------------------*");
        for (int i = 0; i < blocked.length; i++){
            System.out.print("|");
            for (int j = 0; j < blocked[0].length; j++){
                if (i == getPlayerRow() && j == getPlayerCol()) {
                    System.out.print("@");
                }else if (i == getStartRow() && j == getStartCol()) {
                    System.out.print("S");
                }else  if (i == getGoalRow() && j == getGoalCol()) {
                    System.out.print("G");
                }else if (visited[i][j]) {
                    System.out.print(".");
                }else if (blocked[i][j]) {
                    System.out.print("x");
                } else {
                    System.out.print(" ");
                }
            }
            System.out.println("|");
        }
        System.out.println("*---------------------------------------*");
    }

    public int getPlayerRow(){
        return this.player[ROW];
    }

    public int getPlayerCol(){
        return this.player[COL];

    }

    public int getGoalRow(){
        return this.goal[ROW];
    }

    public int getGoalCol(){
        return this.goal[COL];
    }

    public int getStartRow(){
        return this.start[ROW];
    }
    
    public int getStartCol(){
        return this.start[COL];
    }

    public boolean[][] getBlocked(){
        return copyTwoDimBoolArray(blocked);
    }

    public boolean[][] getVisited(){
        return copyTwoDimBoolArray(visited);
    }

    public Scanner getPlayerInput(){
        return this.playerInput;
    }

    public void setPlayerRow(int row){
        if (row < HEIGHT && row >= 0)
            this.player[ROW] = row;
    }

    public void setPlayerCol(int col){
        if (col < WIDTH && col >= 0)
        this.player[COL] = col;
    }


    public void setGoalRow(int row){
        if (row < HEIGHT && row >= 0)
        this.goal[ROW] = row;
    }

    public void setGoalCol(int col){
        if (col < WIDTH && col >= 0)
        this.goal[COL] = col;
    }

    public void setStartRow(int row){
        if (row < HEIGHT && row >= 0)
        this.start[ROW] = row;
    }

    public void setStartCol(int col){
        if (col < WIDTH && col >= 0)
        this.start[COL] = col;
    }

    public void setBlocked(boolean[][] blocked){
        this.blocked = copyTwoDimBoolArray(blocked);
    }

    public void setVisited(boolean[][] visited){
        this.visited = copyTwoDimBoolArray(visited);
    }

    public void setPlayerInput(Scanner playerInput){
        this.playerInput = playerInput;
    }

    private boolean[][] copyTwoDimBoolArray(boolean[][] arrayToCopy){
        boolean[][] placeHolder = new boolean[arrayToCopy.length][arrayToCopy[0].length];
        for (int i = 0; i < arrayToCopy.length; i++){
            for (int j = 0; j < arrayToCopy[0].length; j++){
                placeHolder[i][j] = arrayToCopy[i][j];
            }
        }
        return placeHolder;
    }

    private void prompt(){
        printMaze();
        System.out.print("Enter your move (up, down, left, right, or q to quit): ");
    }

    private boolean playerAtGoal(){
        return (getPlayerCol() == getGoalCol()) && (getPlayerRow() == getGoalRow());
    }

    private boolean valid(int row, int col){
        return row < 19 && row > -1 && col < 39 && col > -1 && !blocked[row][col];
    }

    private void visit(int row, int col){
        visited[row][col] = true;
    }

    private void loadMaze(String mazefile) throws FileNotFoundException
    {
        blocked = new boolean[HEIGHT][WIDTH];
        visited = new boolean[HEIGHT][WIDTH];
        player = new int[] {0,0};
        start = new int[] {0,0};
        goal = new int[] {0,0};

        File  fileName = new File(mazefile);
        Scanner readingMaze = new Scanner(fileName);

        for (int i = 0; i < blocked.length; i++){
            for (int j = 0; j < blocked[0].length; j++){
                String character = readingMaze.next();
                switch (character) {
                    case "1":
                        blocked[i][j] = true;
                        break;
                    case "0":
                        blocked[i][j] = false;
                        break;
                    case "S":
                        setStartRow(i);
                        setStartCol(j);
                        setPlayerRow(i);
                        setPlayerCol(j);
                        break;
                    case "G":
                        setGoalRow(i);
                        setGoalCol(j);
                        break;
                    default:
                        break;
                }
            }
        }
    }

    private boolean makeMove(String move){
        char letter = move.toLowerCase().charAt(0);
        switch (letter) {
            case 'q':
                return true;
            case 'd':
                if (valid(getPlayerRow() + 1, getPlayerCol())){
                    visit(getPlayerRow() + 1, getPlayerCol());
                    setPlayerRow(getPlayerRow() + 1);
                }
                break;
            case 'u':
                if (valid(getPlayerRow() - 1, getPlayerCol())){
                    visit(getPlayerRow() - 1, getPlayerCol());
                    setPlayerRow(getPlayerRow() - 1);
                }
                break;
            case 'l':
                if (valid(getPlayerRow(), getPlayerCol() - 1)){
                    visit(getPlayerRow(), getPlayerCol() - 1);
                    setPlayerCol(getPlayerCol() - 1);
                }
                break;
            case 'r':
                if (valid(getPlayerRow(), getPlayerCol() + 1)){
                    visit(getPlayerRow(), getPlayerCol() + 1);
                    setPlayerRow(getPlayerRow() + 1);
                }
                break;
        }
        return playerAtGoal();

    }
}
